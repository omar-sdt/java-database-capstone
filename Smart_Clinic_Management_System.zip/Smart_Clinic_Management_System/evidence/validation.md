# Observed validation — 8 November 2026

Executed in the IBM Skills Network Cloud IDE using Java 21 (project targets Java 17), Maven 3.9.14, MySQL 8.0 and MongoDB 7.

- Maven clean verify: 3 tests, 0 failures, 0 errors, 0 skipped.
- API smoke test: 12 checks passed (including rejected invalid credentials, cross-patient access, invalid token, duplicate booking, and successful prescription persistence).
- Three curl commands succeeded; exact responses are stored in this folder.
- MySQL SHOW TABLES, five fictional patient records and all three stored procedure outputs are stored in sql-results.txt.
- Actual browser screenshots: admin-login.png, doctor-login.png, patient-login.png, add-doctor.png, patient-search.png, doctor-appointments.png.

The GitHub repository was created from the starter, but these modifications have not been published because the GitHub integration returned HTTP 403. Assessment text responses 19–26 were filled; no final submission was made. Source links and screenshot uploads are still pending.
